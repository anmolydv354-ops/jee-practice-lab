import random
from pathlib import Path

import pandas as pd
import streamlit as st

# ============================================================
# JEE PRACTICE LAB
# A beginner-friendly Streamlit project for JEE practice.
# ============================================================

st.set_page_config(
    page_title="JEE Practice Lab",
    page_icon="🎓",
    layout="wide",
)

DATA_FILE = Path(__file__).parent / "questions.csv"
REQUIRED_COLUMNS = [
    "exam", "subject", "chapter", "difficulty", "question",
    "option_a", "option_b", "option_c", "option_d", "answer",
    "explanation",
]


@st.cache_data
def load_questions(file_path: str) -> pd.DataFrame:
    """Load and validate the question bank."""
    data = pd.read_csv(file_path)
    data.columns = [str(column).strip().lower() for column in data.columns]

    missing = [column for column in REQUIRED_COLUMNS if column not in data.columns]
    if missing:
        raise ValueError("Missing required CSV columns: " + ", ".join(missing))

    # Clean text fields so filtering and answer checking are consistent.
    text_columns = REQUIRED_COLUMNS
    for column in text_columns:
        data[column] = data[column].fillna("").astype(str).str.strip()

    data["exam"] = data["exam"].str.strip()
    data["subject"] = data["subject"].str.strip()
    data["chapter"] = data["chapter"].str.strip()
    data["difficulty"] = data["difficulty"].str.title()
    data["answer"] = data["answer"].str.upper()

    data = data[
        (data["exam"] != "")
        & (data["subject"] != "")
        & (data["chapter"] != "")
        & (data["question"] != "")
        & (data["answer"].isin(["A", "B", "C", "D"]))
    ].copy()

    if data.empty:
        raise ValueError(
            "The CSV has no usable questions. Check that question, category, "
            "and answer fields are filled and answers are A, B, C, or D."
        )

    return data.reset_index(drop=True)


def initialize_state() -> None:
    defaults = {
        "test_questions": [],
        "submitted": False,
        "results": [],
        "performance_history": [],
        "test_id": 0,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def start_new_test(questions: pd.DataFrame, count: int) -> None:
    """Select a random set of questions and reset test-specific state."""
    selected = questions.sample(n=count, replace=False, random_state=None)
    st.session_state.test_questions = selected.to_dict("records")
    st.session_state.submitted = False
    st.session_state.results = []
    st.session_state.test_id += 1


initialize_state()

st.title("🎓 JEE Practice Lab")
st.write(
    "A practice and self-review tool for JEE learners. Choose an exam, subject, "
    "chapter, and difficulty, then review your score and learning trends."
)

with st.expander("About this project", expanded=False):
    st.markdown(
        """
        **Purpose:** help learners practise multiple-choice questions and reflect
        on their performance.

        **Features**
        - Filter questions by exam, subject, chapter, and difficulty
        - Random question selection
        - Automatic scoring and explanations
        - Accuracy and chapter-wise progress summaries
        - Practice suggestions based on recorded results

        **Technology:** Python, Streamlit, and Pandas.

        This is an educational prototype. The included questions are sample
        demonstration questions, not an official or complete JEE question bank.
        """
    )

st.divider()

# Load question bank safely.
try:
    df = load_questions(str(DATA_FILE))
except FileNotFoundError:
    st.error(
        "I could not find `questions.csv`. Put it in the same folder as `app.py`."
    )
    st.stop()
except (ValueError, pd.errors.ParserError, UnicodeDecodeError) as error:
    st.error(f"Could not load the question bank: {error}")
    st.stop()

# Sidebar settings.
st.sidebar.header("⚙️ Test Settings")
exam_options = sorted(df["exam"].unique().tolist())
exam = st.sidebar.selectbox("Exam", exam_options)

subject_options = sorted(
    df.loc[df["exam"] == exam, "subject"].unique().tolist()
)
if not subject_options:
    st.warning("No subjects are available for this exam.")
    st.stop()
subject = st.sidebar.selectbox("Subject", subject_options)

chapter_options = sorted(
    df.loc[
        (df["exam"] == exam) & (df["subject"] == subject), "chapter"
    ].unique().tolist()
)
if not chapter_options:
    st.warning("No chapters are available for this subject.")
    st.stop()
chapter = st.sidebar.selectbox("Chapter", chapter_options)

difficulty_options = ["All", "Easy", "Medium", "Hard"]
difficulty = st.sidebar.selectbox("Difficulty", difficulty_options)

available = df[
    (df["exam"] == exam)
    & (df["subject"] == subject)
    & (df["chapter"] == chapter)
].copy()

if difficulty != "All":
    available = available[available["difficulty"] == difficulty]

st.sidebar.caption(f"{len(available)} question(s) available for this selection.")

if len(available) == 0:
    st.info("No questions match these settings. Choose another chapter or difficulty.")
else:
    number_of_questions = st.sidebar.slider(
        "Number of questions",
        min_value=1,
        max_value=len(available),
        value=min(5, len(available)),
    )
    if st.sidebar.button("🚀 Start / Restart Test", type="primary", use_container_width=True):
        start_new_test(available, number_of_questions)
        st.rerun()

# Display current test. Use a form so answers are submitted together.
if st.session_state.test_questions:
    st.header("📝 Practice Test")
    if st.session_state.submitted:
        st.info("This test has been submitted. Start/restart a test from the sidebar to practise again.")
    else:
        st.caption(
            f"{len(st.session_state.test_questions)} question(s) · "
            f"{exam} · {subject} · {chapter}"
        )

        with st.form(key=f"answer_form_{st.session_state.test_id}"):
            selected_answers = {}
            for index, question in enumerate(st.session_state.test_questions):
                st.markdown(f"#### Question {index + 1}")
                st.write(question["question"])

                options = {
                    "A": question["option_a"],
                    "B": question["option_b"],
                    "C": question["option_c"],
                    "D": question["option_d"],
                }
                labels = [f"{letter}. {text}" for letter, text in options.items()]
                selected_label = st.radio(
                    "Choose one answer",
                    labels,
                    key=f"answer_{st.session_state.test_id}_{index}",
                    index=None,
                )
                selected_answers[index] = (
                    selected_label[0] if selected_label else None
                )
                st.divider()

            submitted = st.form_submit_button("✅ Submit Test", type="primary")

        if submitted:
            unanswered = [
                index + 1 for index, answer in selected_answers.items()
                if answer is None
            ]
            if unanswered:
                st.warning(
                    "Please answer every question before submitting. "
                    "Unanswered question(s): " + ", ".join(map(str, unanswered))
                )
            else:
                results = []
                score = 0
                for index, question in enumerate(st.session_state.test_questions):
                    user_answer = selected_answers[index]
                    correct_answer = question["answer"]
                    is_correct = user_answer == correct_answer
                    score += int(is_correct)
                    results.append(
                        {
                            "question": question["question"],
                            "user_answer": user_answer,
                            "correct_answer": correct_answer,
                            "correct": is_correct,
                            "explanation": question["explanation"],
                            "subject": question["subject"],
                            "chapter": question["chapter"],
                        }
                    )

                total = len(st.session_state.test_questions)
                accuracy = (score / total * 100) if total else 0.0

                st.session_state.results = results
                st.session_state.submitted = True
                st.session_state.performance_history.append(
                    {
                        "exam": exam,
                        "subject": subject,
                        "chapter": chapter,
                        "difficulty": difficulty,
                        "score": score,
                        "total": total,
                        "accuracy": accuracy,
                    }
                )
                st.rerun()

# Results are rendered from session state, so they remain visible on reruns.
if st.session_state.submitted and st.session_state.results:
    st.divider()
    st.header("📊 Test Results")

    total = len(st.session_state.results)
    score = sum(1 for result in st.session_state.results if result["correct"])
    accuracy = score / total * 100 if total else 0.0

    metric1, metric2, metric3 = st.columns(3)
    metric1.metric("Score", f"{score}/{total}")
    metric2.metric("Accuracy", f"{accuracy:.1f}%")
    if accuracy >= 80:
        performance = "Strong"
    elif accuracy >= 60:
        performance = "Developing"
    else:
        performance = "Needs practice"
    metric3.metric("Practice status", performance)

    if accuracy < 60:
        st.warning("Suggestion: review the chapter notes and try another set of questions.")
    elif accuracy < 80:
        st.info("Suggestion: review the questions you missed, then practise this chapter again.")
    else:
        st.success("Good work. Try a different chapter or increase the difficulty.")

    st.subheader("📚 Answer Review")
    for index, result in enumerate(st.session_state.results, start=1):
        with st.expander(f"Question {index} — {'Correct' if result['correct'] else 'Review this answer'}"):
            st.write(result["question"])
            st.write(f"Your answer: **{result['user_answer']}**")
            st.write(f"Correct answer: **{result['correct_answer']}**")
            if result["correct"]:
                st.success("Correct")
            else:
                st.error("Not quite correct")
            st.write("**Explanation:**")
            st.write(result["explanation"])

# Progress and recommendations.
history = st.session_state.performance_history
if history:
    st.divider()
    st.header("📈 Progress Dashboard")
    history_df = pd.DataFrame(history)

    total_tests = len(history_df)
    total_questions = int(history_df["total"].sum())
    total_correct = int(history_df["score"].sum())
    overall_accuracy = (
        total_correct / total_questions * 100 if total_questions else 0.0
    )

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Tests taken", total_tests)
    col2.metric("Questions answered", total_questions)
    col3.metric("Overall accuracy", f"{overall_accuracy:.1f}%")
    col4.metric("Chapters practised", history_df["chapter"].nunique())

    st.subheader("Chapter-wise performance")
    chapter_analysis = (
        history_df.groupby(["exam", "subject", "chapter"], as_index=False)
        .agg(
            Tests=("chapter", "count"),
            Questions=("total", "sum"),
            Correct=("score", "sum"),
        )
    )
    chapter_analysis["Average accuracy"] = (
        chapter_analysis["Correct"] / chapter_analysis["Questions"] * 100
    ).round(1)

    def status_for_accuracy(value: float) -> str:
        if value < 60:
            return "Needs practice"
        if value < 80:
            return "Developing"
        return "Strong"

    chapter_analysis["Practice status"] = chapter_analysis["Average accuracy"].apply(
        status_for_accuracy
    )
    st.dataframe(chapter_analysis, use_container_width=True, hide_index=True)

    # Recommend the chapter with the lowest accumulated accuracy.
    st.subheader("🎯 Personalised Practice Suggestion")
    recommendation_df = chapter_analysis.sort_values(
        ["Average accuracy", "Questions"], ascending=[True, False]
    )
    weakest = recommendation_df.iloc[0]
    st.write(
        f"Based on the tests recorded in this session, consider revisiting "
        f"**{weakest['chapter']}** ({weakest['subject']}). Its combined accuracy "
        f"is **{weakest['Average accuracy']:.1f}%** across "
        f"**{int(weakest['Questions'])} question(s)**."
    )
    st.caption(
        "Progress is stored in this browser session only. It resets when the "
        "session is cleared or the app restarts; permanent accounts and cloud storage "
        "are not included in this prototype."
    )

st.divider()
st.caption("JEE Practice Lab · Independent educational prototype · Python + Streamlit + Pandas")
