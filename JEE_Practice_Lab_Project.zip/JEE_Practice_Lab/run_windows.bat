@echo off
title JEE Practice Lab
cd /d "%~dp0"
echo Installing required packages...
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo Could not install packages. Check that Python is installed and added to PATH.
    pause
    exit /b 1
)
echo.
echo Starting JEE Practice Lab...
python -m streamlit run app.py
if errorlevel 1 (
    echo.
    echo The app did not start. Read the error message above.
    pause
)
pause
