# JEE Practice Lab

A beginner-friendly educational project built with Python, Streamlit, and Pandas.

## Files in this folder

- `app.py` — the Streamlit application
- `questions.csv` — a small demonstration question bank
- `requirements.txt` — Python packages needed
- `README.md` — setup and usage instructions

## How to run it

1. Install Python 3.10 or newer from https://www.python.org/downloads/.
2. Extract this ZIP file into a folder.
3. Open a terminal or Command Prompt in that folder.
4. Install the packages:

   ```bash
   python -m pip install -r requirements.txt
   ```

5. Start the app:

   ```bash
   python -m streamlit run app.py
   ```

6. Streamlit will show a local URL (usually `http://localhost:8501`). Open it in your browser.

## How to add questions

Open `questions.csv` in Excel, Google Sheets, or a text editor. Add one question per row and keep the column names unchanged:

`exam, subject, chapter, difficulty, question, option_a, option_b, option_c, option_d, answer, explanation`

- `exam`: for example, `JEE Main` or `JEE Advanced`
- `subject`: `Physics`, `Chemistry`, or `Mathematics`
- `chapter`: the chapter name
- `difficulty`: `Easy`, `Medium`, or `Hard`
- `answer`: one letter only: `A`, `B`, `C`, or `D`

Save the file as CSV UTF-8. The example questions are demonstrations to help test the app; they are not an official or comprehensive JEE question bank. Verify question answers and explanations before using any question in a real study resource.

## Current limitations

- Progress history lasts only for the current app session.
- There is no user login, database, cloud syncing, or timer.
- Recommendations are based on accuracy in the recorded session, not a trained AI model.
- This is a prototype and should be described honestly as a personal academic project. Do not claim features you have not built or tested.
